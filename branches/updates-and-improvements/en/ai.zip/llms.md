# info.gefyra.training#0.1.0: Schulungs-IG(en)

## Pages

* [Home](index.md)
* [Downloads](downloads.md)
* [Changelog](changelog.md)
* [Artifacts Summary](artifacts.md)

## Resources

### Resource Profiles

* [MyPatient](StructureDefinition-MyPatient.md)

### ImplementationGuides

* [Schulungs-IG](ImplementationGuide-info.gefyra.training.md)

### Examples

* [PatientExample (Patient)](Patient-PatientExample.md)
